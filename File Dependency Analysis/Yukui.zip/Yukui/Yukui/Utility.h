#ifndef MTUTILITY_H
#define MTUTILITY_H
// MTutility.h

#include <iostream>
#include <ios>

void Title(const std::string& str, char underline='=', std::ostream& out=std::cout);

#endif
