
class c4
{
    void gf4()
    {
	    int q=globalValue1;
    }
}