
#include "FirstTestfile.h"
class mm2{};
class classFromSecondtestfile
{
};

int gv2 = 9;