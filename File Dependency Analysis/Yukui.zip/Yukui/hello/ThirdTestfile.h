

#include "FirstTestfile.h"

class classFromThirdTestFile:public A
{
};
class G
{
};