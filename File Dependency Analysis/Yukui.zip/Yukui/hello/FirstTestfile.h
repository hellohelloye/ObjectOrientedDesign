class A
{
};
class B
{
};

void gf();
std::string gf2();

class B:public A
{
};
class C
{
};
class D
{
};

int globalValue1;
double gv2;
short gv3;

class E
{
}
class W
{
};
class H
{
};

struct structClasselement
{
  std::string type;
  std::string name;

};
enum enumClassrelation { inheritance, composition};
//typedef element simple;
