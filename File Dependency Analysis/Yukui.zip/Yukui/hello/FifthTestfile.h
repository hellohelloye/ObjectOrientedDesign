class c5
{
	int cgv= gv2;
}